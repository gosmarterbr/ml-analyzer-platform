from flask import Blueprint, request, jsonify, session
from werkzeug.security import check_password_hash
from src.models.user import db, User
from datetime import datetime
import jwt
import os

auth_bp = Blueprint('auth', __name__)

SECRET_KEY = os.environ.get('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT')

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': 'Email e senha são obrigatórios'}), 400
        
        user = User.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': 'Email ou senha inválidos'}), 401
        
        if user.status != 'active':
            return jsonify({'error': 'Conta inativa ou suspensa'}), 401
        
        # Invalidar outras sessões (sessão única)
        User.query.filter(User.id != user.id, User.session_token.isnot(None)).update({User.session_token: None})
        
        # Gerar novo token de sessão
        session_token = user.generate_session_token()
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Criar JWT token
        token_payload = {
            'user_id': user.id,
            'email': user.email,
            'session_token': session_token
        }
        token = jwt.encode(token_payload, SECRET_KEY, algorithm='HS256')
        
        return jsonify({
            'success': True,
            'token': token,
            'user': user.to_dict()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/validate', methods=['POST'])
def validate_token():
    try:
        data = request.get_json()
        token = data.get('token')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 400
        
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            session_token = payload.get('session_token')
            
            user = User.query.get(user_id)
            
            if not user or user.session_token != session_token:
                return jsonify({'error': 'Token inválido ou sessão expirada'}), 401
            
            if user.status != 'active':
                return jsonify({'error': 'Conta inativa'}), 401
            
            return jsonify({
                'success': True,
                'user': user.to_dict()
            })
            
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    try:
        data = request.get_json()
        token = data.get('token')
        
        if token:
            try:
                payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
                user_id = payload.get('user_id')
                
                user = User.query.get(user_id)
                if user:
                    user.session_token = None
                    db.session.commit()
                    
            except jwt.InvalidTokenError:
                pass
        
        return jsonify({'success': True, 'message': 'Logout realizado com sucesso'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/check-analysis-limit', methods=['POST'])
def check_analysis_limit():
    try:
        data = request.get_json()
        token = data.get('token')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 400
        
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            
            user = User.query.get(user_id)
            
            if not user:
                return jsonify({'error': 'Usuário não encontrado'}), 404
            
            can_analyze = user.can_analyze()
            
            return jsonify({
                'success': True,
                'can_analyze': can_analyze,
                'plan': user.plan,
                'analyses_used': user.analyses_used,
                'analyses_limit': user.analyses_limit
            })
            
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/increment-analysis', methods=['POST'])
def increment_analysis():
    try:
        data = request.get_json()
        token = data.get('token')
        
        if not token:
            return jsonify({'error': 'Token não fornecido'}), 400
        
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            
            user = User.query.get(user_id)
            
            if not user:
                return jsonify({'error': 'Usuário não encontrado'}), 404
            
            if not user.can_analyze():
                return jsonify({'error': 'Limite de análises atingido'}), 403
            
            user.increment_analysis()
            db.session.commit()
            
            return jsonify({
                'success': True,
                'analyses_used': user.analyses_used,
                'analyses_limit': user.analyses_limit
            })
            
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

