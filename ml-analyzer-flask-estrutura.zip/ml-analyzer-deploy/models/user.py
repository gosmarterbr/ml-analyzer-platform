from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import uuid

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    plan = db.Column(db.String(20), default='basic')  # basic, premium
    status = db.Column(db.String(20), default='active')  # active, inactive, suspended
    analyses_used = db.Column(db.Integer, default=0)
    analyses_limit = db.Column(db.Integer, default=50)  # 50 for basic, -1 for unlimited
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    session_token = db.Column(db.String(255), unique=True)  # Para sessão única
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_session_token(self):
        self.session_token = str(uuid.uuid4())
        return self.session_token
    
    def can_analyze(self):
        if self.plan == 'premium':
            return True
        return self.analyses_used < self.analyses_limit
    
    def increment_analysis(self):
        if self.plan == 'basic':
            self.analyses_used += 1
    
    def reset_monthly_usage(self):
        if self.plan == 'basic':
            self.analyses_used = 0
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'plan': self.plan,
            'status': self.status,
            'analyses_used': self.analyses_used,
            'analyses_limit': self.analyses_limit,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

class License(db.Model):
    __tablename__ = 'licenses'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    api_key = db.Column(db.String(255), unique=True, nullable=False)
    status = db.Column(db.String(20), default='active')  # active, expired, suspended
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    
    user = db.relationship('User', backref=db.backref('licenses', lazy=True))
    
    def is_valid(self):
        if self.status != 'active':
            return False
        if self.expires_at and self.expires_at < datetime.utcnow():
            return False
        return True
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'api_key': self.api_key,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }

class Analytics(db.Model):
    __tablename__ = 'analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    product_url = db.Column(db.String(500), nullable=False)
    product_title = db.Column(db.String(200))
    analysis_data = db.Column(db.Text)  # JSON string
    score = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('analytics', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'product_url': self.product_url,
            'product_title': self.product_title,
            'analysis_data': self.analysis_data,
            'score': self.score,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class StripeConfig(db.Model):
    __tablename__ = 'stripe_config'
    
    id = db.Column(db.Integer, primary_key=True)
    publishable_key = db.Column(db.String(255))
    secret_key = db.Column(db.String(255))
    webhook_secret = db.Column(db.String(255))
    basic_price_id = db.Column(db.String(255))
    premium_price_id = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'publishable_key': self.publishable_key,
            'basic_price_id': self.basic_price_id,
            'premium_price_id': self.premium_price_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

