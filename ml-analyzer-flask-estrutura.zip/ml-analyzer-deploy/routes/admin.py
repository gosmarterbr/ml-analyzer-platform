from flask import Blueprint, request, jsonify, render_template, redirect, url_for, session
from src.models.user import db, User, Analytics, StripeConfig
from datetime import datetime, timedelta
import uuid

admin_bp = Blueprint('admin', __name__)

# Credenciais fixas do admin
ADMIN_EMAIL = 'admin@mlanalyzer.com'
ADMIN_PASSWORD = 'admin123'

@admin_bp.route('/login-page')
def admin_login_page():
    return '''
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin - ML Analyzer</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
            .login-container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
            .logo { text-align: center; margin-bottom: 30px; }
            .logo h1 { color: #333; font-size: 28px; margin-bottom: 5px; }
            .logo p { color: #666; font-size: 14px; }
            .form-group { margin-bottom: 20px; }
            .form-group label { display: block; margin-bottom: 5px; color: #333; font-weight: 500; }
            .form-group input { width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 5px; font-size: 16px; transition: border-color 0.3s; }
            .form-group input:focus { outline: none; border-color: #667eea; }
            .btn-login { width: 100%; padding: 12px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 5px; font-size: 16px; font-weight: 500; cursor: pointer; transition: transform 0.2s; }
            .btn-login:hover { transform: translateY(-2px); }
            .error { color: #e74c3c; text-align: center; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="logo">
                <h1>ML Analyzer</h1>
                <p>Painel Administrativo</p>
            </div>
            <form id="loginForm">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn-login">Entrar</button>
                <div id="error" class="error"></div>
            </form>
        </div>
        
        <script>
            document.getElementById('loginForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                const errorDiv = document.getElementById('error');
                
                try {
                    const response = await fetch('/api/admin/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email, password })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        localStorage.setItem('admin_token', data.token);
                        window.location.href = '/api/admin/dashboard';
                    } else {
                        errorDiv.textContent = data.error || 'Erro no login';
                    }
                } catch (error) {
                    errorDiv.textContent = 'Erro de conexão';
                }
            });
        </script>
    </body>
    </html>
    '''

@admin_bp.route('/login', methods=['POST'])
def admin_login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
            # Gerar token simples para admin
            admin_token = str(uuid.uuid4())
            session['admin_token'] = admin_token
            
            return jsonify({
                'success': True,
                'token': admin_token,
                'message': 'Login realizado com sucesso'
            })
        else:
            return jsonify({'error': 'Credenciais inválidas'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/dashboard')
def admin_dashboard():
    return '''
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Admin - ML Analyzer</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f6fa; }
            
            .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; z-index: 1000; }
            .sidebar .logo { padding: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
            .sidebar .logo h2 { font-size: 20px; margin-bottom: 5px; }
            .sidebar .logo p { font-size: 12px; opacity: 0.8; }
            
            .sidebar .menu { padding: 20px 0; }
            .sidebar .menu-item { display: block; padding: 15px 20px; color: white; text-decoration: none; transition: background 0.3s; border: none; width: 100%; text-align: left; cursor: pointer; font-size: 14px; }
            .sidebar .menu-item:hover, .sidebar .menu-item.active { background: rgba(255,255,255,0.1); }
            .sidebar .menu-item i { margin-right: 10px; width: 16px; }
            
            .main-content { margin-left: 250px; padding: 20px; }
            .header { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { color: #333; font-size: 24px; }
            .header .actions { display: flex; gap: 10px; }
            .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; transition: transform 0.2s; }
            .btn-primary { background: #667eea; color: white; }
            .btn-success { background: #2ed573; color: white; }
            .btn:hover { transform: translateY(-2px); }
            
            .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
            .stat-card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            .stat-card .number { font-size: 32px; font-weight: bold; color: #667eea; margin-bottom: 5px; }
            .stat-card .label { color: #666; font-size: 14px; }
            
            .content-section { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: none; }
            .content-section.active { display: block; }
            
            .users-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .users-table th, .users-table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
            .users-table th { background: #f8f9fa; font-weight: 600; }
            .users-table tr:hover { background: #f8f9fa; }
            
            .modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
            .modal-content { background: white; margin: 5% auto; padding: 30px; width: 90%; max-width: 500px; border-radius: 10px; }
            .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
            .modal-header h3 { color: #333; }
            .close { font-size: 24px; cursor: pointer; color: #999; }
            .close:hover { color: #333; }
            
            .form-group { margin-bottom: 15px; }
            .form-group label { display: block; margin-bottom: 5px; color: #333; font-weight: 500; }
            .form-group input, .form-group select { width: 100%; padding: 10px; border: 2px solid #e1e5e9; border-radius: 5px; font-size: 14px; }
            .form-group input:focus, .form-group select:focus { outline: none; border-color: #667eea; }
            
            .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; }
            .status-active { background: #d4edda; color: #155724; }
            .status-inactive { background: #f8d7da; color: #721c24; }
            .plan-basic { background: #e2e3e5; color: #383d41; }
            .plan-premium { background: #ffeaa7; color: #6c5ce7; }
        </style>
    </head>
    <body>
        <div class="sidebar">
            <div class="logo">
                <h2>ML Analyzer</h2>
                <p>Painel Administrativo</p>
            </div>
            <div class="menu">
                <button class="menu-item active" onclick="showSection('dashboard')">
                    📊 Dashboard
                </button>
                <button class="menu-item" onclick="showSection('users')">
                    👥 Usuários
                </button>
                <button class="menu-item" onclick="showSection('subscriptions')">
                    💳 Assinaturas
                </button>
                <button class="menu-item" onclick="showSection('analytics')">
                    📈 Análises
                </button>
                <button class="menu-item" onclick="showSection('revenue')">
                    💰 Receita
                </button>
                <button class="menu-item" onclick="showSection('support')">
                    🎧 Suporte
                </button>
                <button class="menu-item" onclick="showSection('settings')">
                    ⚙️ Configurações
                </button>
            </div>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>Dashboard Administrativo</h1>
                <div class="actions">
                    <button class="btn btn-primary" onclick="refreshData()">Atualizar</button>
                    <button class="btn btn-success" onclick="exportData()">Exportar</button>
                </div>
            </div>
            
            <!-- Dashboard Section -->
            <div id="dashboard" class="content-section active">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="number" id="totalUsers">0</div>
                        <div class="label">Usuários Totais</div>
                    </div>
                    <div class="stat-card">
                        <div class="number" id="activeSubscriptions">0</div>
                        <div class="label">Assinaturas Ativas</div>
                    </div>
                    <div class="stat-card">
                        <div class="number" id="totalAnalyses">0</div>
                        <div class="label">Análises Realizadas</div>
                    </div>
                    <div class="stat-card">
                        <div class="number" id="monthlyRevenue">R$ 0</div>
                        <div class="label">Receita Mensal</div>
                    </div>
                </div>
            </div>
            
            <!-- Users Section -->
            <div id="users" class="content-section">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2>Gerenciamento de Usuários</h2>
                    <button class="btn btn-success" onclick="openAddUserModal()">Adicionar Usuário</button>
                </div>
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Plano</th>
                            <th>Status</th>
                            <th>Análises</th>
                            <th>Criado em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <!-- Users will be loaded here -->
                    </tbody>
                </table>
            </div>
            
            <!-- Other sections -->
            <div id="subscriptions" class="content-section">
                <h2>Gerenciamento de Assinaturas</h2>
                <p>Funcionalidade em desenvolvimento...</p>
            </div>
            
            <div id="analytics" class="content-section">
                <h2>Análises da Plataforma</h2>
                <p>Funcionalidade em desenvolvimento...</p>
            </div>
            
            <div id="revenue" class="content-section">
                <h2>Análise de Receita</h2>
                <p>Funcionalidade em desenvolvimento...</p>
            </div>
            
            <div id="support" class="content-section">
                <h2>Central de Suporte</h2>
                <p>Funcionalidade em desenvolvimento...</p>
            </div>
            
            <div id="settings" class="content-section">
                <h2>Configurações do Sistema</h2>
                
                <!-- Stripe Configuration -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h3 style="margin-bottom: 15px; color: #333;">🔧 Configuração do Stripe</h3>
                    <form id="stripeConfigForm">
                        <div class="form-group">
                            <label for="publishableKey">Chave Pública (Publishable Key):</label>
                            <input type="text" id="publishableKey" name="publishable_key" placeholder="pk_test_..." required>
                        </div>
                        <div class="form-group">
                            <label for="secretKey">Chave Secreta (Secret Key):</label>
                            <input type="password" id="secretKey" name="secret_key" placeholder="sk_test_..." required>
                        </div>
                        <div class="form-group">
                            <label for="webhookSecret">Webhook Secret (Opcional):</label>
                            <input type="password" id="webhookSecret" name="webhook_secret" placeholder="whsec_...">
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button type="button" class="btn btn-primary" onclick="testStripeConnection()">Testar Conexão</button>
                            <button type="submit" class="btn btn-success">Salvar Configuração</button>
                        </div>
                    </form>
                    <div id="stripeStatus" style="margin-top: 15px;"></div>
                </div>
                
                <!-- Stripe Products -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h3 style="margin-bottom: 15px; color: #333;">💳 Produtos do Stripe</h3>
                    <div style="display: flex; gap: 15px; margin-bottom: 15px;">
                        <div style="flex: 1; padding: 15px; background: white; border-radius: 5px; border: 1px solid #ddd;">
                            <h4 style="color: #667eea; margin-bottom: 5px;">Plano Básico</h4>
                            <p style="margin: 0; color: #666;">R$ 59,00/mês - 50 análises</p>
                            <small id="basicPriceId" style="color: #999;">Price ID: Não configurado</small>
                        </div>
                        <div style="flex: 1; padding: 15px; background: white; border-radius: 5px; border: 1px solid #ddd;">
                            <h4 style="color: #667eea; margin-bottom: 5px;">Plano Premium</h4>
                            <p style="margin: 0; color: #666;">R$ 199,00/mês - Ilimitado</p>
                            <small id="premiumPriceId" style="color: #999;">Price ID: Não configurado</small>
                        </div>
                    </div>
                    <button type="button" class="btn btn-success" onclick="createStripeProducts()">Criar Produtos no Stripe</button>
                    <div id="productsStatus" style="margin-top: 15px;"></div>
                </div>
                
                <!-- System Info -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                    <h3 style="margin-bottom: 15px; color: #333;">ℹ️ Informações do Sistema</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <div>
                            <strong>Versão:</strong><br>
                            <span style="color: #666;">ML Analyzer v5.0</span>
                        </div>
                        <div>
                            <strong>Banco de Dados:</strong><br>
                            <span style="color: #666;">SQLite</span>
                        </div>
                        <div>
                            <strong>Status:</strong><br>
                            <span style="color: #2ed573;">✅ Online</span>
                        </div>
                        <div>
                            <strong>Última Atualização:</strong><br>
                            <span style="color: #666;" id="lastUpdate">Carregando...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Add User Modal -->
        <div id="addUserModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Adicionar Novo Usuário</h3>
                    <span class="close" onclick="closeAddUserModal()">&times;</span>
                </div>
                <form id="addUserForm">
                    <div class="form-group">
                        <label for="userName">Nome Completo:</label>
                        <input type="text" id="userName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="userEmail">Email:</label>
                        <input type="email" id="userEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="userPassword">Senha:</label>
                        <input type="password" id="userPassword" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="userPlan">Plano:</label>
                        <select id="userPlan" name="plan" required>
                            <option value="basic">Básico (R$ 59/mês)</option>
                            <option value="premium">Premium (R$ 199/mês)</option>
                        </select>
                    </div>
                    <div style="display: flex; gap: 10px; justify-content: flex-end;">
                        <button type="button" class="btn" onclick="closeAddUserModal()">Cancelar</button>
                        <button type="submit" class="btn btn-success">Adicionar Usuário</button>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            let currentSection = 'dashboard';
            
            function showSection(sectionName) {
                // Hide all sections
                document.querySelectorAll('.content-section').forEach(section => {
                    section.classList.remove('active');
                });
                
                // Remove active class from all menu items
                document.querySelectorAll('.menu-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                // Show selected section
                document.getElementById(sectionName).classList.add('active');
                
                // Add active class to clicked menu item
                event.target.classList.add('active');
                
                currentSection = sectionName;
                
                // Load data for specific sections
                if (sectionName === 'users') {
                    loadUsers();
                } else if (sectionName === 'dashboard') {
                    loadDashboardStats();
                }
            }
            
            async function loadDashboardStats() {
                try {
                    const response = await fetch('/api/admin/stats', {
                        headers: { 'Authorization': 'Bearer ' + localStorage.getItem('admin_token') }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        document.getElementById('totalUsers').textContent = data.stats.total_users;
                        document.getElementById('activeSubscriptions').textContent = data.stats.active_subscriptions;
                        document.getElementById('totalAnalyses').textContent = data.stats.total_analyses;
                        document.getElementById('monthlyRevenue').textContent = 'R$ ' + data.stats.monthly_revenue.toFixed(2);
                    }
                } catch (error) {
                    console.error('Erro ao carregar estatísticas:', error);
                }
            }
            
            async function loadUsers() {
                try {
                    const response = await fetch('/api/admin/users', {
                        headers: { 'Authorization': 'Bearer ' + localStorage.getItem('admin_token') }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        const tbody = document.getElementById('usersTableBody');
                        tbody.innerHTML = '';
                        
                        data.users.forEach(user => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${user.id}</td>
                                <td>${user.name}</td>
                                <td>${user.email}</td>
                                <td><span class="status-badge plan-${user.plan}">${user.plan === 'basic' ? 'Básico' : 'Premium'}</span></td>
                                <td><span class="status-badge status-${user.status}">${user.status === 'active' ? 'Ativo' : 'Inativo'}</span></td>
                                <td>${user.analyses_used}/${user.analyses_limit === -1 ? '∞' : user.analyses_limit}</td>
                                <td>${new Date(user.created_at).toLocaleDateString('pt-BR')}</td>
                                <td>
                                    <button class="btn btn-primary" onclick="editUser(${user.id})">Editar</button>
                                    <button class="btn" onclick="deleteUser(${user.id})" style="background: #e74c3c; color: white;">Excluir</button>
                                </td>
                            `;
                            tbody.appendChild(row);
                        });
                    }
                } catch (error) {
                    console.error('Erro ao carregar usuários:', error);
                }
            }
            
            function openAddUserModal() {
                document.getElementById('addUserModal').style.display = 'block';
            }
            
            function closeAddUserModal() {
                document.getElementById('addUserModal').style.display = 'none';
                document.getElementById('addUserForm').reset();
            }
            
            document.getElementById('addUserForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const userData = {
                    name: formData.get('name'),
                    email: formData.get('email'),
                    password: formData.get('password'),
                    plan: formData.get('plan')
                };
                
                try {
                    const response = await fetch('/api/admin/users', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + localStorage.getItem('admin_token')
                        },
                        body: JSON.stringify(userData)
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        alert('Usuário adicionado com sucesso!');
                        closeAddUserModal();
                        loadUsers();
                    } else {
                        alert('Erro: ' + data.error);
                    }
                } catch (error) {
                    alert('Erro de conexão');
                }
            });
            
            function refreshData() {
                if (currentSection === 'dashboard') {
                    loadDashboardStats();
                } else if (currentSection === 'users') {
                    loadUsers();
                }
            }
            
            function exportData() {
                alert('Funcionalidade de exportação em desenvolvimento');
            }
            
            function editUser(userId) {
                alert('Funcionalidade de edição em desenvolvimento');
            }
            
            function deleteUser(userId) {
                if (confirm('Tem certeza que deseja excluir este usuário?')) {
                    // Implementar exclusão
                    alert('Funcionalidade de exclusão em desenvolvimento');
                }
            }
            
            // Load initial data
            loadDashboardStats();
            loadStripeConfig();
            
            // Stripe Configuration Functions
            async function loadStripeConfig() {
                try {
                    const response = await fetch('/api/admin/stripe/config', {
                        headers: { 'Authorization': 'Bearer ' + localStorage.getItem('admin_token') }
                    });
                    const data = await response.json();
                    
                    if (data.success && data.config.configured) {
                        document.getElementById('publishableKey').value = data.config.publishable_key;
                        document.getElementById('basicPriceId').textContent = 'Price ID: ' + (data.config.basic_price_id || 'Não configurado');
                        document.getElementById('premiumPriceId').textContent = 'Price ID: ' + (data.config.premium_price_id || 'Não configurado');
                        
                        document.getElementById('stripeStatus').innerHTML = '<div style="color: #2ed573;">✅ Stripe configurado</div>';
                    }
                } catch (error) {
                    console.error('Erro ao carregar configuração Stripe:', error);
                }
            }
            
            async function testStripeConnection() {
                const secretKey = document.getElementById('secretKey').value;
                if (!secretKey) {
                    alert('Digite a chave secreta primeiro');
                    return;
                }
                
                try {
                    const response = await fetch('/api/admin/stripe/test-connection', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + localStorage.getItem('admin_token')
                        },
                        body: JSON.stringify({ secret_key: secretKey })
                    });
                    
                    const data = await response.json();
                    const statusDiv = document.getElementById('stripeStatus');
                    
                    if (data.success) {
                        statusDiv.innerHTML = '<div style="color: #2ed573;">✅ ' + data.message + '</div>';
                    } else {
                        statusDiv.innerHTML = '<div style="color: #e74c3c;">❌ ' + data.error + '</div>';
                    }
                } catch (error) {
                    document.getElementById('stripeStatus').innerHTML = '<div style="color: #e74c3c;">❌ Erro de conexão</div>';
                }
            }
            
            document.getElementById('stripeConfigForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const configData = {
                    publishable_key: formData.get('publishable_key'),
                    secret_key: formData.get('secret_key'),
                    webhook_secret: formData.get('webhook_secret')
                };
                
                try {
                    const response = await fetch('/api/admin/stripe/config', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + localStorage.getItem('admin_token')
                        },
                        body: JSON.stringify(configData)
                    });
                    
                    const data = await response.json();
                    const statusDiv = document.getElementById('stripeStatus');
                    
                    if (data.success) {
                        statusDiv.innerHTML = '<div style="color: #2ed573;">✅ ' + data.message + '</div>';
                        loadStripeConfig();
                    } else {
                        statusDiv.innerHTML = '<div style="color: #e74c3c;">❌ ' + data.error + '</div>';
                    }
                } catch (error) {
                    document.getElementById('stripeStatus').innerHTML = '<div style="color: #e74c3c;">❌ Erro ao salvar configuração</div>';
                }
            });
            
            async function createStripeProducts() {
                try {
                    const response = await fetch('/api/admin/stripe/create-products', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + localStorage.getItem('admin_token')
                        }
                    });
                    
                    const data = await response.json();
                    const statusDiv = document.getElementById('productsStatus');
                    
                    if (data.success) {
                        statusDiv.innerHTML = '<div style="color: #2ed573;">✅ ' + data.message + '</div>';
                        document.getElementById('basicPriceId').textContent = 'Price ID: ' + data.basic_price_id;
                        document.getElementById('premiumPriceId').textContent = 'Price ID: ' + data.premium_price_id;
                    } else {
                        statusDiv.innerHTML = '<div style="color: #e74c3c;">❌ ' + data.error + '</div>';
                    }
                } catch (error) {
                    document.getElementById('productsStatus').innerHTML = '<div style="color: #e74c3c;">❌ Erro ao criar produtos</div>';
                }
            }
            
            // Update last update time
            document.getElementById('lastUpdate').textContent = new Date().toLocaleString('pt-BR');
        </script>
    </body>
    </html>
    '''

@admin_bp.route('/stats')
def admin_stats():
    try:
        # Verificar se é admin (simplificado)
        admin_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not admin_token or admin_token != session.get('admin_token'):
            return jsonify({'error': 'Não autorizado'}), 401
        
        total_users = User.query.count()
        active_users = User.query.filter_by(status='active').count()
        total_analyses = Analytics.query.count()
        
        # Calcular receita mensal (simulado)
        basic_users = User.query.filter_by(plan='basic', status='active').count()
        premium_users = User.query.filter_by(plan='premium', status='active').count()
        monthly_revenue = (basic_users * 59) + (premium_users * 199)
        
        return jsonify({
            'success': True,
            'stats': {
                'total_users': total_users,
                'active_subscriptions': active_users,
                'total_analyses': total_analyses,
                'monthly_revenue': monthly_revenue
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users', methods=['GET', 'POST'])
def admin_users():
    try:
        # Verificar se é admin
        admin_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not admin_token or admin_token != session.get('admin_token'):
            return jsonify({'error': 'Não autorizado'}), 401
        
        if request.method == 'GET':
            users = User.query.all()
            return jsonify({
                'success': True,
                'users': [user.to_dict() for user in users]
            })
        
        elif request.method == 'POST':
            data = request.get_json()
            
            # Verificar se email já existe
            existing_user = User.query.filter_by(email=data.get('email')).first()
            if existing_user:
                return jsonify({'error': 'Email já cadastrado'}), 400
            
            # Criar novo usuário
            user = User(
                name=data.get('name'),
                email=data.get('email'),
                plan=data.get('plan', 'basic')
            )
            user.set_password(data.get('password'))
            
            # Definir limite de análises baseado no plano
            if user.plan == 'premium':
                user.analyses_limit = -1  # Ilimitado
            else:
                user.analyses_limit = 50  # Básico
            
            db.session.add(user)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Usuário criado com sucesso',
                'user': user.to_dict()
            })
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

