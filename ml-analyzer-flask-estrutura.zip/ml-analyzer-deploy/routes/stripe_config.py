from flask import Blueprint, request, jsonify, session
from src.models.user import db, StripeConfig
import stripe

stripe_bp = Blueprint('stripe', __name__)

@stripe_bp.route('/config', methods=['GET', 'POST'])
def stripe_config():
    try:
        # Verificar se é admin
        admin_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not admin_token or admin_token != session.get('admin_token'):
            return jsonify({'error': 'Não autorizado'}), 401
        
        if request.method == 'GET':
            config = StripeConfig.query.first()
            if config:
                return jsonify({
                    'success': True,
                    'config': {
                        'publishable_key': config.publishable_key,
                        'basic_price_id': config.basic_price_id,
                        'premium_price_id': config.premium_price_id,
                        'configured': True
                    }
                })
            else:
                return jsonify({
                    'success': True,
                    'config': {
                        'publishable_key': '',
                        'basic_price_id': '',
                        'premium_price_id': '',
                        'configured': False
                    }
                })
        
        elif request.method == 'POST':
            data = request.get_json()
            
            publishable_key = data.get('publishable_key')
            secret_key = data.get('secret_key')
            webhook_secret = data.get('webhook_secret')
            
            if not publishable_key or not secret_key:
                return jsonify({'error': 'Chaves do Stripe são obrigatórias'}), 400
            
            # Testar conexão com Stripe
            try:
                stripe.api_key = secret_key
                stripe.Account.retrieve()
            except Exception as e:
                return jsonify({'error': f'Erro ao conectar com Stripe: {str(e)}'}), 400
            
            # Salvar ou atualizar configuração
            config = StripeConfig.query.first()
            if config:
                config.publishable_key = publishable_key
                config.secret_key = secret_key
                config.webhook_secret = webhook_secret
            else:
                config = StripeConfig(
                    publishable_key=publishable_key,
                    secret_key=secret_key,
                    webhook_secret=webhook_secret
                )
                db.session.add(config)
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Configuração do Stripe salva com sucesso'
            })
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stripe_bp.route('/create-products', methods=['POST'])
def create_stripe_products():
    try:
        # Verificar se é admin
        admin_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not admin_token or admin_token != session.get('admin_token'):
            return jsonify({'error': 'Não autorizado'}), 401
        
        config = StripeConfig.query.first()
        if not config or not config.secret_key:
            return jsonify({'error': 'Stripe não configurado'}), 400
        
        stripe.api_key = config.secret_key
        
        try:
            # Criar produto básico
            basic_product = stripe.Product.create(
                name='ML Analyzer - Plano Básico',
                description='50 análises por mês para otimização de anúncios no Mercado Livre'
            )
            
            basic_price = stripe.Price.create(
                unit_amount=5900,  # R$ 59,00 em centavos
                currency='brl',
                recurring={'interval': 'month'},
                product=basic_product.id
            )
            
            # Criar produto premium
            premium_product = stripe.Product.create(
                name='ML Analyzer - Plano Premium',
                description='Análises ilimitadas e funcionalidades avançadas de IA'
            )
            
            premium_price = stripe.Price.create(
                unit_amount=19900,  # R$ 199,00 em centavos
                currency='brl',
                recurring={'interval': 'month'},
                product=premium_product.id
            )
            
            # Salvar IDs dos preços
            config.basic_price_id = basic_price.id
            config.premium_price_id = premium_price.id
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Produtos criados no Stripe com sucesso',
                'basic_price_id': basic_price.id,
                'premium_price_id': premium_price.id
            })
            
        except stripe.error.StripeError as e:
            return jsonify({'error': f'Erro do Stripe: {str(e)}'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stripe_bp.route('/test-connection', methods=['POST'])
def test_stripe_connection():
    try:
        # Verificar se é admin
        admin_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not admin_token or admin_token != session.get('admin_token'):
            return jsonify({'error': 'Não autorizado'}), 401
        
        data = request.get_json()
        secret_key = data.get('secret_key')
        
        if not secret_key:
            return jsonify({'error': 'Chave secreta é obrigatória'}), 400
        
        try:
            stripe.api_key = secret_key
            account = stripe.Account.retrieve()
            
            return jsonify({
                'success': True,
                'message': 'Conexão com Stripe estabelecida com sucesso',
                'account_id': account.id,
                'country': account.country
            })
            
        except stripe.error.StripeError as e:
            return jsonify({'error': f'Erro do Stripe: {str(e)}'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stripe_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    try:
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        config = StripeConfig.query.first()
        if not config or not config.webhook_secret:
            return jsonify({'error': 'Webhook não configurado'}), 400
        
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, config.webhook_secret
            )
        except ValueError:
            return jsonify({'error': 'Payload inválido'}), 400
        except stripe.error.SignatureVerificationError:
            return jsonify({'error': 'Assinatura inválida'}), 400
        
        # Processar eventos do Stripe
        if event['type'] == 'checkout.session.completed':
            session_data = event['data']['object']
            # Aqui você processaria a criação/ativação da assinatura
            # Por exemplo, ativar o usuário no sistema
            
        elif event['type'] == 'invoice.payment_succeeded':
            invoice = event['data']['object']
            # Processar pagamento bem-sucedido
            
        elif event['type'] == 'invoice.payment_failed':
            invoice = event['data']['object']
            # Processar falha no pagamento
            
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

